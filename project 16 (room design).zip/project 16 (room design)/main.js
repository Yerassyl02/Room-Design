/** indicator */

const indicator = document.querySelector('#indicator');
const maxHeight = document.body.scrollHeight - window.innerHeight;

window.addEventListener('scroll', () => {
    const percentage = (window.scrollY / maxHeight) * 100;
    indicator.style.width = `${percentage}%`;
});


/**Burger */

const navSlide = () => {
    const burger = document.querySelector('.burger');
    const nav = document.querySelector('.stroke');
    const navLinks = document.querySelectorAll('.stroke a');

    burger.addEventListener('click', () => {
        nav.classList.toggle('nav-active');

        navLinks.forEach((link, index) => {
            if (link.style.animation) {
                link.style.animation = ''
            } else {
                link.style.animation = `navLinkFade 0.5s ease forwards ${index / 7 + 0.5}s`;
            }
        });

        burger.classList.toggle('toggle');
    });

}

navSlide();